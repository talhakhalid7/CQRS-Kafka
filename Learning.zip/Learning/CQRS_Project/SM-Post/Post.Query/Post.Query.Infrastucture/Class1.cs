﻿namespace Post.Query.Infrastucture;
public class Class1
{

}
