﻿namespace Post.Cmd.Infrastucture;
public class Class1
{

}
