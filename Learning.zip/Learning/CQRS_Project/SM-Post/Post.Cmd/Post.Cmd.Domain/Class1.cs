﻿namespace Post.Cmd.Domain;
public class Class1
{

}
