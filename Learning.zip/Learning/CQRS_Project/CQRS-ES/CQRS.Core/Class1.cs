﻿namespace CQRS.Core;
public class Class1
{

}
